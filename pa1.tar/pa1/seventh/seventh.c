#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv){
	char *array;
	array = (char *)malloc(sizeof(char)*argc);
	//array = argv[1];
	//printf("string argument: %s\n", argv[2]);
	int i;
	int x = 0;
	for(i = 1; i < argc; i++){
		int size = strlen(argv[i]);
		array[x] = (argv[i])[size - 1];
		x++;
	}
	//array[argc - 1] = '\0';
	//printf("\n");
	printf(array);
	//printf("\n");
	return 0;
}
