#include<stdio.h>
#include<stdlib.h>

struct listnode {
  int value;
  struct listnode * next;
};
void getSize(struct listnode*);
void delete(struct listnode**, int);
int duplicates(struct listnode*, int);
void traverse(struct listnode*);
void insert(struct listnode **, int);
void cleanup(struct listnode*);

void getSize(struct listnode *head){
	struct listnode* t1= head;
	int count = 0;
  	while(t1 != NULL){
  		count++;
    		t1 = t1->next;
  	}
  	
  	printf("%d\n", count);
}

void cleanup(struct listnode* hold){
 	struct listnode *node1 = hold;
  	struct listnode *node2 = NULL;
  
  	while(node1 != NULL){
    		node2 = node1;
    		node1 = node1->next;
    		free(node2);
  	}
}
int duplicates(struct listnode *head, int value1){
	struct listnode* t1= head;
	int x = 0;
  	while(t1 != NULL){
    		//printf("%d\n", t1->value);if
    		if(t1->value == value1){
    			x = 1;
    		}	
    		t1 = t1->next;
  	}
  	return x;
}

void traverse(struct listnode *head){
	struct listnode* node1 = head;
  	while(node1 != NULL){
    		printf("%d\t", node1->value);
    		node1 = node1->next;
  	}
  	
}
void delete(struct listnode **head, int value1){
	struct listnode *t1 = *head;
	if(t1 == NULL){
		return;
	}	
	if(t1->value == value1){
		*head = t1->next;
		return;
	}
  	while(t1->next != NULL){
  		if(t1->next->value == value1){
  			if(t1->next->next != NULL){
  				t1->next = t1->next->next;
  				return;
  			}
  			if(t1->next->next == NULL){
  				t1->next = NULL;
  				return;
  			}
  		}
  		t1 = t1->next;
  	}
  	if(t1->next == NULL){
  		return;
  	}
}

void insert(struct listnode **head, int value1){
	struct listnode *hold = *head;
	
	if(hold == NULL){
		struct listnode *newNode = NULL;
		newNode = (struct listnode *)malloc(1* sizeof(struct listnode));
		newNode->value = value1;
		newNode->next = NULL;
		*head = newNode;
		//printf("Value to be inserted at head: %d\n", value1);
		//printf("\n");
		return;
		//return head;
	}
	
	while(hold != NULL){
		if(hold->value < value1){
			//printf("CHECK");
			if((hold->next != NULL) && ((hold->next->value) > value1)){
				//struct listnode *temp = (struct listnode *)malloc(1* sizeof(struct listnode));
				struct listnode *add = (struct listnode *)malloc(1* sizeof(struct listnode));
				//temp = hold->next;
				add->value = value1;
				add->next = hold->next;
				hold->next = add;
				//printf("Value to be inserted: %d\n", value1);
				//printf("\n");
				return;
				//return head;
			}
			if(hold->next == NULL){
				//struct listnode *temp = (struct listnode *)malloc(1* sizeof(struct listnode));
				struct listnode *add = (struct listnode *)malloc(1* sizeof(struct listnode));
				//temp = hold->next;
				add->value = value1;
				add->next = NULL;
				hold->next = add;
				//printf("Value to be inserted: %d\n", value1);
				//printf("\n");
				return;
				//return head;
			}
		}
		if((hold->value > value1) && (hold == *head)){
			//struct listnode *temp = (struct listnode *)malloc(1* sizeof(struct 
			//listnode));
			struct listnode *add = (struct listnode *)malloc(1* sizeof(struct listnode));
			add->value = value1;
			add->next = hold;
			*head = add;
			//printf("Value to be inserted: %d\n", value1);
			//printf("\n");
			return;
			//return head;
		}
		hold = hold->next;
	}
	
	//return 0;
}

int main(int argc, char** argv){
	int b;
	char a;
	struct listnode * head = (struct listnode *)malloc(1* sizeof(struct listnode));
	head = NULL;
	
	FILE *fp;
	fp = fopen(argv[1], "r");

	if(fp == NULL){
		return 0;
	}
	
	while(fscanf(fp, "%c %d\n", &a, &b) == 2){
		if(a == 'i'){
			if(duplicates(head, b) == 0){
				insert(&head, b);
			}
		}
		if(a == 'd'){
			delete(&head, b);
		}
  		//printf("%c %d\n", a, b);
 	}
 	//while(head != NULL){
 		//struct listnode *iterate = head;
    		//printf("%d\n", iterate->value);
    		//iterate = iterate->next;
  	//}
  	getSize(head);
 	traverse(head);
 	cleanup(head);
 	return 0;
 	
 	
}
