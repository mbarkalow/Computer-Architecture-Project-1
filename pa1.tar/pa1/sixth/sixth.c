#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printNewWord(char*, int);

void printNewWord(char* array, int size){
	//printf("TESTING FUNCTION\n");
	char *newArray = (char *)malloc(sizeof(char)*(size + 1));
	int i;
	strcpy(newArray,array);
	//printf("%s\n", newArray);
	for(i = 0; i < size; i++){
		//printf("New Array element: %c\n", newArray[i]);
	}
	if(newArray[0] == ('a') || newArray[0] == ('e') || newArray[0] == ('i') || newArray[0] == ('o') || newArray[0] == ('u') || newArray[0] == ('A') || newArray[0] == ('E') || newArray[0] == ('I') || newArray[0] == ('O') || newArray[0] == ('U')){
		char *newArray1 = (char *)malloc(sizeof(char)*(size + 4));
		int i;
		for(i = 0; i < size; i++){
			newArray1[i] = newArray[i];
		}
		newArray1[size] = 'y';
		newArray1[size + 1] = 'a';
		newArray1[size + 2] = 'y';
		newArray1[size + 3] = '\0';
		printf("%s ", newArray1);
		return;
	} else { 
		for(i = 0;i < (size + 1); i++){
			if(newArray[i] == ('a') || newArray[i] == ('e') || newArray[i] == ('i') || newArray[i] == ('o') || newArray[i] == ('u') || newArray[i] == ('A') || newArray[i] == ('E') || newArray[i] == ('I') || newArray[i] == ('O') || newArray[i] == ('U')){
				//printf("CHECKING\n");
				char *newArray2 = (char *)malloc(sizeof(char)*(i));
				int x;
				for(x = 0; x < i; x++){
					newArray2[x] = newArray[x];
				}
				char *newArray3 = (char *)malloc(sizeof(char)*(size + 3));
				int hold = i;
				for(x = 0; hold < size; x++){
					newArray3[x] = newArray[hold];
					hold++;
				}
				//printf("newArray2: %s\n", newArray2);
				strncat(newArray3, newArray2, i);
				//printf("newArray3: %s\n", newArray3);
				newArray3[size] = 'a';
				newArray3[size + 1] = 'y';
				newArray3[size + 2] = '\0';
				//newArray3[size + 2] = '\0';
				//printf("newArray2: %s\n", newArray2);
				printf("%s ", newArray3);
				return;
			}
		}
	}
			
	
}	

int main(int argc, char** argv){
	int i;
	for(i = 1; i < argc; i++){
		printNewWord(argv[i], strlen(argv[i]));	
	}
	
	return 0;
}	
