#include <stdio.h>
#include <stdlib.h>

/*
void insert(int **, int, int, int);
int add(int *, int **, int, int, int, int, int);

int add(int *array, int **resultMatrix, int sizeStoreArray, int row1, int col1, int row2, int col2){
	int i;
	int x;
	int sum;
	for(i = 0; i < sizeStoreArray; i++){
		//if(i != 0){
			//insert(resultMatrix, row1, col2);
		//}
		for(x = 0; x < col1; x++){
			sum = sum + array[x];
		}
		//assuming i am using linked list
		temp = sum;
		list.add(temp);
		sum = 0;
	}	
}

void insert(int **resultMatrix, int row, int col, int sum){
	
}*/

int main(int argc, char** argv){
	if(argc != 2){
		printf("not enough arguments\n");
		return 0;
 	}

	FILE *fp;
	fp = fopen(argv[1], "r");

	if(fp == NULL){
		return 0;
	}
	int a,n,m,b;
	fscanf(fp, "%d %d", &n, &m);
	int size1 = m * n;
	int *array;
	array = (int *)malloc(sizeof(int)*size1);
	int i = 0;
	while(i < size1){
		fscanf(fp, "%d", &a);
		array[i] = a;
		i++;
		//printf("%d\n", a);
	}
	int d, e;
	fscanf(fp, "%d %d", &d, &e);
	if(m != d){
		printf("bad-matrices");
		return 0;
	}
	int size2 = d * e;
	int *array2;
	array2 = (int *)malloc(sizeof(int)*size2);
	int x = 0;
	//printf("\nNext Array:\n");
	while(x < size2){
		fscanf(fp, "%d", &b);
		array2[x] = b;
		x++;
		//printf("%d\n", b);
	}
	int k;
	
	int **matrix1 = malloc(sizeof(int*)*n);
	for(k = 0; k < n; k++){
		matrix1[k] = malloc(sizeof(int)*m);
	}
	
	int f, g;
	int z = 0;
	for(f = 0; f < n; f++){
		for(g = 0; g < m; g++){
			matrix1[f][g] = array[z];
			z++;
			//printf("Element: %d\n", matrix1[f][g]);
		}
	}
	//printf("\n");
	//printf("Next matrix");
	//printf("\n");
	int h;
	int **matrix2 = malloc(sizeof(int*)*d);
	for(h = 0; h < d; h++){
		matrix2[h] = malloc(sizeof(int)*e);
	}
	
	int for1, for2;
	int w = 0;
	for(for1 = 0; for1 < d; for1++){
		for(for2 = 0; for2 < e; for2++){
			matrix2[for1][for2] = array2[w];
			w++;
			//printf("Element: %d\n", matrix2[for1][for2]);
		}
	}
	
	int **resultMatrix = malloc(sizeof(int*)*n);
	for(h = 0; h < n; h++){
		resultMatrix[h] = malloc(sizeof(int)*e);
	}
	//int sizeStoreArray = (n * m * d * e) / m
	//int *storeArray;
	//storeArray = (int *)malloc(sizeof(int)*sizeStoreArray);
	int l;
	int j;
	int p;
	int product;
	//int q;
	int sum = 0;
	
	for(l = 0; l < n; l++){
		//printf("TESTING FOR ERROR");
		for(j = 0; j < e; j++){
				
			for(p = 0; p < m; p++){
				product = (matrix1[l][p]) * (matrix2[p][j]);
				sum = sum + product;
				//printf("Product of two ints: %d\n", numToAdd);
				//storeArray[p] = numToAdd;
			}
			resultMatrix[l][j] = sum;
			sum = 0;
		}
	}
	
	// add(storeArray, resultMatrix, sizeStoreArray, n, m, d, e);
	// return 9 number list
	// put into resultMatrix
	
	int r;
	int s;
	//printf("\n");
	for(r = 0; r < n; r++){
		for(s = 0; s < e; s++){
			printf("%d\t", resultMatrix[r][s]);
		}
		printf("\n");
	}
	
	fclose(fp);
	return 0;	
}
