#include <stdio.h>
#include <stdlib.h>

int checkRepeats(int *, int, int);

int checkRepeats(int *array, int numToCheck, int ArraySize){
	int i;
	int count = 0;
	for(i = 0; i < ArraySize; i++){
		if(array[i] == numToCheck){
			count++;
		}
		if(count > 1){
			return count;
		}
	}
	return count;
}

int main(int argc, char** argv){
	int size;
	if(argc != 2){
		printf("not enough arguments\n");
		return 0;
 	}

	FILE *fp;
	fp = fopen(argv[1], "r");

	if(fp == NULL){
		return 0;
	}
	
	fscanf(fp, "%d", &size);
	int nums = size * size;
	int *array;
	array = (int *)malloc(sizeof(int)*nums);
	int i = 0;
	int a;
	while(i < nums){
		fscanf(fp, "%d", &a);
		array[i] = a;
		i++;
		//printf("%d\n", a);
	}
	fclose(fp);
	int s;
	int count;
	for(s = 0; s < nums; s++){
		count = checkRepeats(array, array[s], nums);
		if(count > 1){
			printf("not-magic");
			return 0;
		}
	}
	
	int **matrix1 = malloc(sizeof(int*)*size);
	int k;
	for(k = 0; k < size; k++){
		matrix1[k] = malloc(sizeof(int)*size);
	}
	int f, g;
	int z = 0;
	for(f = 0; f < size; f++){
		for(g = 0; g < size; g++){
			matrix1[f][g] = array[z];
			z++;
			//printf("Element: %d\n", matrix1[f][g]);
		}
	}
	
	int *array2;
	array2 = (int *)malloc(sizeof(int)*size);
	int *array3;
	array3 = (int *)malloc(sizeof(int)*size);
	int hold;
	int sum = 0;
	int x, y;
	for(x = 0; x < size; x++){
		//printf("Checking for errors");
		for(y = 0; y < size; y++){
			hold = matrix1[x][y];
			sum = sum + hold;
		}
		//printf("Sum is: %d\n", sum);
		array2[x] = sum;
		sum = 0;
	}
	for(x = 0; x < size; x++){
		//printf("Checking for errors");
		for(y = 0; y < size; y++){
			hold = matrix1[y][x];
			sum = sum + hold;
		}
		//printf("Sum2 is: %d\n", sum);
		array3[x] = sum;
		sum = 0;
	}
	
	int p;
	int current;
	int majorsum = 0;
	for(p = 0; p < size; p++){
		current = matrix1[p][p];
		majorsum = majorsum + current;
	}
	//printf("Major Diagonal Sum: %d\n", majorsum);
	
	int current1;
	int minorsum = 0;
	int q = 0;
	int r;
	for(r = size - 1; r > -1; r--){
		current1 = matrix1[q][r];
		minorsum = minorsum + current1;
		q++;
	}
	if(majorsum != minorsum){
		printf("not-magic");
		return 0;
	}
	//printf("Minor Diagonal Sum: %d\n", minorsum);
	int w;
	for(w = 0; w < size; w++){
		if(array2[w] != majorsum){
			printf("not-magic");
			return 0;
		}
		//printf("Array Element1: %d\n", array2[w]);
	}
	int m;
	for(m = 0; m < size; m++){
		if(array3[m] != majorsum){
			printf("not-magic");
			return 0;
		}
		//printf("Array Element2: %d\n", array3[m]);
	}
	
	printf("magic");
	
	
	return 0;
	
	
}
