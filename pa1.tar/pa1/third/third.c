#include <stdio.h>
#include <stdlib.h>

struct listnode {
	int data;
	struct listnode * next;
};


void insert(struct listnode**, int, int);
void search(struct listnode**, int, int);
int duplicates(struct listnode**, int, int);

void insert(struct listnode **array, int value, int size){
	//struct listnode *copy[] = *array;
	struct listnode* current = (struct listnode *)malloc(1* sizeof(struct listnode));
	int hashKey;
	//printf("CHECKING INSIDE INSERT\n");
	if(value < 0){
		int posvalue = abs(value);
		hashKey = size - posvalue;
	} else {
		hashKey = value % size;
		//hashKey = abs(hashKey);
	}
	//printf("hashKey: %d\n", hashKey);
	if(array[hashKey] == NULL){
		struct listnode *newnode = (struct listnode *)malloc(1* sizeof(struct listnode));
		newnode->data = value;
		newnode->next = NULL;
		array[hashKey] = newnode;
		printf("inserted\n");
		return;
	}
	else if(array[hashKey] != NULL){
		int pos = 0;
		
		current = array[hashKey];
		while(current->next != NULL){
			current = current->next;
			//printf("checking list\n");
			pos++;
		}
		struct listnode *newnode = (struct listnode *)malloc(1* sizeof(struct listnode));
		current->next = newnode;
		newnode->data = value;
		newnode->next = NULL;
		printf("inserted\n");
		//printf("inserted element: %d\n", value);
		//printf("position: %d\n", pos);
		return;
	}
}
void search(struct listnode **array, int value, int size){
	struct listnode* current1 = (struct listnode *)malloc(1* sizeof(struct listnode));
	int hashKey;
	if(value < 0){
		int posvalue = abs(value);
		hashKey = size - posvalue;
	} else {
		hashKey = value % size;
		//hashKey = abs(hashKey);
	}
	//printf("hashKey: %d\n", hashKey);
	
	if(array[hashKey] == NULL){
		printf("absent\n");
		return;
	}
	if(array[hashKey]->data == value){
		printf("present\n");
		return;
	}
	current1 = array[hashKey];
	while(current1->next != NULL){
		if(current1->next->data == value){
			printf("present\n");
			return;
		}else{
			current1 = current1->next;
		}
	}
	printf("absent\n");
}

int duplicates(struct listnode** array, int value, int size){
	int count = 0;
	int hashKey;
	struct listnode* current2 = (struct listnode *)malloc(1* sizeof(struct listnode));
	if(value < 0){
		int posvalue = abs(value);
		hashKey = size - posvalue;
	} else {
		hashKey = value % size;
		//hashKey = abs(hashKey);
	}
	//printf("hashKey: %d\n", hashKey);
	
	if(array[hashKey] == NULL){
		//printf("CHECKING NULL HASHKEY\n");
		return count;
	}
	if(array[hashKey]->data == value){
		count++;
		return count;
	}
	current2 = array[hashKey];
	while(current2->next != NULL){
		//printf("CHECKING WHILE LOOP\n");
		if(current2->next->data == value){
			count++;
			return count;
		}else{
			current2 = current2->next;
		}
	}
	//printf("Count: %d\n", count);
	return count;
}

int main(int argc, char** argv){
	if(argc != 2){
		printf("not enough arguments\n");
		return 0;
 	}

	FILE *fp;
	fp = fopen(argv[1], "r");

	if(fp == NULL){
		return 0;
	}
	int size = 10000;
	struct listnode *array[size];
	int i;
	for(i = 0; i < size; i++){
		array[i] = (struct listnode *)malloc(1* sizeof(struct listnode));
		array[i] = NULL;
	}
	char a;
	int b;
	while(fscanf(fp, "%c %d\n", &a, &b) == 2){
		if(a == 'i'){
			//printf("CHECKING\n");
			if(duplicates(array, b, size) == 0){
				//printf("CHECKING INSERT\n");
				insert(array, b, size);
			}
			else {
				printf("duplicate\n");
			}
		}
		else if(a == 's'){
			search(array, b, size);
		}
	}
	fclose(fp);
	return 0;
}
