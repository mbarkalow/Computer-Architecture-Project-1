#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv){
	int a;	

	if(argc != 2){
		printf("not enough arguments\n");
		return 0;
 	}

	FILE *fp;
	fp = fopen(argv[1], "r");

	if(fp == NULL){
		return 0;
	}
	
	fscanf(fp, "%d", &a);

	int *array;
	array = (int *)malloc(sizeof(int)*a);
	
	int b = 0;
	int i = 0;
	while(fscanf(fp, "%d\n", &b) == 1){
		//printf("%d\n", b);
		array[i] = b;
		i++;
 	}
	fclose(fp);
	int y;
	int loop = 1;
	while(loop == 1){
	loop = 0;
		for(y = 0; y < a - 1; y++){
			if((((array[y]) % 2) != 0) && (((array[y + 1]) % 2) == 0)){
				// if first y is odd and second is even swap them.
				int temp = array[y];
				array[y] = array[y + 1];
				array[y + 1] = temp;
				loop = 1;
			}
		}
	}
	int e;
	int loop1 = 1;
	while(loop1 == 1){
	loop1 = 0;
		for(e = 0; e < a - 1; e++){
			if(((array[e]) > (array[e + 1]) && (((array[e]) % 2) == 0) && 				(((array[e + 1]) % 2) == 0))){
				int temp = array[e];
				array[e] = array[e + 1];
				array[e + 1] = temp;
				loop1 = 1;
			}
			if(((array[e]) > (array[e + 1]) && (((array[e]) % 2) != 0) && 				(((array[e + 1]) % 2) != 0))){
				int temp = array[e];
				array[e] = array[e + 1];
				array[e + 1] = temp;
				loop1 = 1;
			}
		}
	}
	int x;
	for(x = 0; x < a; x++){
		printf("%d\t", array[x]);
	}
	printf("\n");
	free(array);
	return 0;
	
}

