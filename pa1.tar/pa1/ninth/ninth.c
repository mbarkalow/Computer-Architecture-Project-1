#include<stdio.h>
#include<stdlib.h>

struct bstnode{
	int key;
	struct bstnode *left;
	struct bstnode *right;
};

void insert(struct bstnode **, int);
void search(struct bstnode*, int);
int checkDuplicates(struct bstnode*, int);
void delete(struct bstnode **, int);
void freenodes(struct bstnode **);


int checkDuplicates(struct bstnode *root, int value){
	struct bstnode *current = root;
	int duplicates = 0;
	//int height = 1;
	if(current == NULL){
		return duplicates;
	}
	
	while(current != NULL){
		//printf("Current Height: %d\n", height);
		if(current->key < value){
			//printf("Current height1: %d\n", height);
			//printf("Current value1: %d\n", current->key);
			if(current->right == NULL){
				return duplicates;
			}
			current = current->right;
		}
		
		else if(current->key > value){
			//printf("Current height: %d\n", height);
			//printf("Current value: %d\n", current->key);
			if(current->left == NULL){
				return duplicates;
			}
			current = current->left;
		}
		
		else if(current->key == value){
			duplicates++;
			return duplicates;
		}
		
	}
	return duplicates;
}

void search(struct bstnode *root, int value){
	struct bstnode *current = root;
	int height = 1;
	if(current == NULL){
		printf("absent\n");
	}
	
	while(current != NULL){
		//printf("Current Height: %d\n", height);
		if(current->key < value){
			//printf("Current height1: %d\n", height);
			//printf("Current value1: %d\n", current->key);
			if(current->right == NULL){
				printf("absent\n");
				return;
			}
			current = current->right;
		}
		
		else if(current->key > value){
			//printf("Current height: %d\n", height);
			//printf("Current value: %d\n", current->key);
			if(current->left == NULL){
				printf("absent\n");
				return;
			}
			current = current->left;
		}
		
		else if(current->key == value){
			//printf("Current height: %d\n", height);
			//printf("Current value: %d\n", current->key);
			printf("present %d\n", height);
			return;
		}
		height++;
	}
}

void delete(struct bstnode **root, int value){
	char branch;
	struct bstnode *current = *root;
	struct bstnode *parent = current;
	struct bstnode *hold;
	struct bstnode *parentHold;
	//int height = 1;
	if(current == NULL){
		printf("fail\n");
	}
	while(current != NULL){
		//printf("Current Height: %d\n", height);
		if(current->key < value){
			//printf("Current height1: %d\n", height);
			//printf("Current value1: %d\n", current->key);
			if(current->right == NULL){
				printf("fail\n");
				return;
			}
			parent = current;
			branch = 'r';
			current = current->right;
		}
		
		else if(current->key > value){
			//printf("Current height: %d\n", height);
			//printf("Current value: %d\n", current->key);
			if(current->left == NULL){
				printf("fail\n");
				return;
			}
			parent = current;
			branch = 'l';
			current = current->left;
		}
		
		else if(current->key == value){
			//printf("Current height: %d\n", height);
			//printf("Current value: %d\n", current->key);
			if(current == *root){
				if((current->right == NULL) && (current->left == NULL)){
					//current = NULL;
					//current->right = NULL;
					//current->left = NULL;
					//*root = current;
					*root = NULL;
					printf("success\n");
					return;
				}
				else if((current->right != NULL) && (current->left != NULL)){
					hold = current;
					hold = hold->right;
					if((hold->left == NULL) && (hold->right == NULL)){
						current->key = hold->key;
						current->right = NULL;
						current->left = NULL;
						printf("success\n");
						*root = current;
						return;
					}
					else if((hold->left != NULL) && (hold->right == NULL)){
						while(hold->left != NULL){
							parentHold = hold;
							hold = hold->left;
						}
						if(hold->right != NULL){
							current->key = hold->key;
							parentHold->left = hold->right;
							*root = current;
							printf("success\n");
							return;
						} else {
							current->key = hold->key;
							parentHold->left = NULL;
							*root = current;
							printf("success\n");
							return;
						}
					}	
					else if((hold->left == NULL) && (hold->right != NULL)){
						current->key = hold->key;
						current->right = hold->right;
						*root = current;
						printf("success\n");
						return;
					}
					while(hold->left != NULL){
						parentHold = hold;
						hold = hold->left;
					}
					current->key = hold->key;
					parentHold->left = NULL;
					*root = current;
					printf("success\n");
					return;
				}
				else if((current->right != NULL) && (current->left == NULL)){
					hold = current;
					hold = hold->right;
					if((hold->left == NULL) && (hold->right == NULL)){
						current->key = hold->key;
						current->right = NULL;
						current->left = NULL;
						printf("success\n");
						*root = current;
						return;
					}
					else if((hold->left != NULL) && (hold->right == NULL)){
						while(hold->left != NULL){
							parentHold = hold;
							hold = hold->left;
						}
						if(hold->right != NULL){
							current->key = hold->key;
							parentHold->left = hold->right;
							*root = current;
							printf("success\n");
							return;
						} else {
							current->key = hold->key;
							parentHold->left = NULL;
							*root = current;
							printf("success\n");
							return;
						}
					}	
					else if((hold->left == NULL) && (hold->right != NULL)){
						current->key = hold->key;
						current->right = hold->right;
						*root = current;
						printf("success\n");
						return;
					}
					while(hold->left != NULL){
						parentHold = hold;
						hold = hold->left;
					}
					current->key = hold->key;
					parentHold->left = NULL;
					*root = current;
					printf("success\n");
					return;
				}
				printf("fail\n");
				return;
			}
			// end of root case
			if((current->right == NULL) && (current->left != NULL)){
				if(branch == 'l'){
					parent->left = current->left;
					printf("success\n");
					return;
				}
				else if(branch == 'r'){
					parent->right = current->left;
					printf("success\n");
					return;
				}
			}
			else if((current->right != NULL) && (current->left == NULL)){
				if(branch == 'l'){
					parent->left = current->right;
					printf("success\n");
					return;
				}
				else if(branch == 'r'){
					parent->right = current->right;
					printf("success\n");
					return;
				}
			}
			else if((current->right == NULL) && (current->left == NULL)){
				if(branch == 'l'){
					parent->left = NULL;
					printf("success\n");
					return;
				}
				else if(branch == 'r'){
					parent->right = NULL;
					printf("success\n");
					return;
				}
			}
			else if((current->right != NULL) && (current->left != NULL)){
				hold = current;
				hold = hold->right;
				if((hold->left == NULL) && (hold->right != NULL)){
					current->key = hold->key;
					current->right = hold->right;
					printf("success\n");
					return;
				}
				else if((hold->left == NULL) && (hold->right == NULL)){
					current->key = hold->key;
					current->right = NULL;
					printf("success\n");
					return;
				}
				while(hold->left != NULL){
					parentHold = hold;
					hold = hold->left;
				}
				if(hold->right != NULL){
					current->key = hold->key;
					parentHold->left = hold->right;
					printf("success\n");
					return;
				} else {
					current->key = hold->key;
					parentHold->left = NULL;
					printf("success\n");
					return;
				}
			}
			//return;
		}
		//height++;
	}
	printf("fail\n");
}

void insert(struct bstnode **root, int value){
	struct bstnode *current = *root;
	int height = 1;
	if(current == NULL){
		struct bstnode *newNode = (struct bstnode *)malloc(1* sizeof(struct bstnode));
		struct bstnode *newNode3 = (struct bstnode *)malloc(1* sizeof(struct bstnode));
		struct bstnode *newNode4 = (struct bstnode *)malloc(1* sizeof(struct bstnode));
		newNode3 = NULL;
		newNode4 = NULL;
		newNode->key = value;
		newNode->right = newNode3;
		newNode->left = newNode4;
		*root = newNode;
		//printf("Value: %d\n", value);
		printf("inserted %d\n", height);
		return;
	}
	
	while(current != NULL){
		height++;
		if(current->key < value){
			if(current->right == NULL){
				struct bstnode *add = (struct bstnode *)malloc(1* sizeof(struct bstnode));
				struct bstnode *newNode1 = (struct bstnode *)malloc(1* sizeof(struct bstnode));
				struct bstnode *newNode2 = (struct bstnode *)malloc(1* sizeof(struct bstnode));
				newNode1 = NULL;
				newNode2 = NULL;
				current->right = add;
				add->key = value;
				add->right = newNode1;
				add->left = newNode2;
				//printf("Value: %d\n", value);
				printf("inserted %d\n", height);
				return;
			}
			current = current->right;
		}
		else if(current->key > value){
			if(current->left == NULL){
				struct bstnode *add = (struct bstnode *)malloc(1* sizeof(struct bstnode));
				struct bstnode *newNode1 = (struct bstnode *)malloc(1* sizeof(struct bstnode));
				struct bstnode *newNode2 = (struct bstnode *)malloc(1* sizeof(struct bstnode));
				newNode1 = NULL;
				newNode2 = NULL;
				current->left = add;
				add->key = value;
				add->right = newNode1;
				add->left = newNode2;
				//printf("Value: %d\n", value);
				printf("inserted %d\n", height);
				return;
			}
			current = current->left;
		}
		//height++;
	}
}

void freenodes(struct bstnode **root){
	struct bstnode *current = *root;
	if(current == NULL){
		return;
	}
	freenodes(&current->left);
	freenodes(&current->right);
	free(current);
}

int main(int argc, char** argv){
	struct bstnode *root = (struct bstnode *)malloc(1* sizeof(struct bstnode));
	root = NULL;
	FILE *fp;
	fp = fopen(argv[1], "r");

	if(fp == NULL){
		return 0;
	}
	char a;
	int b;
	while(fscanf(fp, "%c %d\n", &a, &b) == 2){
		if(a == 'i'){
			if((checkDuplicates(root, b)) == 0){
				insert(&root, b);
			} else {
				printf("duplicate\n");
			}
		}
		if(a == 's'){
			search(root, b);
		}
		if(a == 'd'){
			delete(&root, b);
		}
	}
	freenodes(&root);
	fclose(fp);	
	return 0;
}
